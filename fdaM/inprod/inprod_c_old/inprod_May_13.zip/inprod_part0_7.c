//
//  inprod_part0_7.c
//  
//
//  Created by Harry Jiang on 2016-05-12.
//
//

#include "mex.h"
#include <math.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    #define LAST_APPROX 5
    
    // Macros for output
    #define Y_OUT       plhs[0]
    #define XA          plhs[1]
    #define NS          plhs[2]
    #define DS          plhs[3]
    #define CS          plhs[4]
    
    // Macros for input
    #define ITER        prhs[0]
    #define S_IN        prhs[1]
    #define H_IN        prhs[2]
    
    double *h, *xa, *ns, *s, *ds, *cs, *y;
    int iter, i, j, k, *D;
    
    //create ind
    iter        = (int)mxGetPr(ITER)[0];
    mexPrintf("init passed\n");
    
    //determine ns
    h           = mxGetPr(H_IN);
    NS          = mxCreateDoubleMatrix(1, 1, mxREAL);
    ns          = mxGetPr(NS);
    ns[0]       = 0;
    XA          = mxCreateDoubleMatrix(LAST_APPROX, 1, mxREAL);
    xa          = mxGetPr(XA);
    for (i = 0; i < LAST_APPROX; i++){
        xa[i] = h[iter - LAST_APPROX + i];
        if (fabs(xa[i]) <= fabs(xa[(int)ns[0]])) {
            ns[0] = i;
        }
    }
    mexPrintf("h passed\n");
    
    D               = mxGetDimensions(S_IN);
    mwSize dims[3]  = {LAST_APPROX, D[1], D[2]};
    s               = mxGetPr(S_IN);
    DS              = mxCreateNumericArray(3, dims, mxDOUBLE_CLASS, mxREAL);
    CS              = mxCreateNumericArray(3, dims, mxDOUBLE_CLASS, mxREAL);
    ds              = mxGetPr(DS);
    cs              = mxGetPr(CS);
    Y_OUT           = mxCreateDoubleMatrix(D[1], D[2], mxREAL);
    y               = mxGetPr(Y_OUT);
    mexPrintf("cs/ds/y setup passed\n");
    
    for (i = 0; i < D[1]; i++) {
        for (j = 0; j < D[2]; j++) {
            int index = D[0]*i + D[0]*D[1]*j;
            
            for (k = 0; k < LAST_APPROX; k++) {
                ds[k + index] = s[iter - LAST_APPROX + k + index];
                cs[k + index] = s[iter - LAST_APPROX + k + index];
            }
            
            y[i + D[1]*j] = s[iter - LAST_APPROX + (int)ns[0] + index];
        }
    }
    
    return;
}