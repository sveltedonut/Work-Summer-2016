addpath('/Users/harry/Documents/MATLAB/fdaM')

testbasis = create_fourier_basis([0,1], 21);
testbasis2 = create_fourier_basis([0,1], 11);
harmaccelLfd = harmaccel(testbasis);
harmaccelLfd2 = harmaccel(testbasis2);

% plot(testbasis);

testfdPar = fdPar(testbasis, harmaccelLfd, 1e-7);
testLfd = getLfd(testfdPar);
testfdPar2 = fdPar(testbasis2, harmaccelLfd2, 1e-7);
testLfd2 = getLfd(testfdPar2);

%sq = inprod_Harry(testbasis, testbasis2, testLfd, testLfd2)
sq = inprod_C(testbasis, testbasis2, testLfd, testLfd2)

plot(sq);